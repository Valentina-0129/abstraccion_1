from abc import ABC, abstractmethod

class Factura(ABC):
    
    def __init__(self, cliente):
        self.cliente = cliente
        self.productos = []  
    
    @abstractmethod
    def calcular_total(self):
        pass

    def agregar_producto(self, producto):
        self.productos.append(producto)

class FacturaConProductos(Factura):
    
    def __init__(self, cliente):
        super().__init__(cliente)
    
    def calcular_total(self):
        return sum([producto["precio"] for producto in self.productos])

factura = FacturaConProductos("Juan Pérez")

factura.agregar_producto({"nombre": "Camiseta", "precio": 20})
factura.agregar_producto({"nombre": "Pantalón", "precio": 35})
factura.agregar_producto({"nombre": "Zapatos", "precio": 50})

total = factura.calcular_total()

print(f"Total de la compra para {factura.cliente}: ${total}")

