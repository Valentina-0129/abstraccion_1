from abc import ABC, abstractmethod

class Empleado(ABC):
    
    def __init__(self, nombre, horas_trabajadas, tarifa_hora):
        self.nombre = nombre
        self.horas_trabajadas = horas_trabajadas
        self.tarifa_hora = tarifa_hora
        
    @abstractmethod
    def calcular_salario(self):
        pass

class EmpleadoPorHora(Empleado):
    
    def __init__(self, nombre, horas_trabajadas, tarifa_hora):
        super().__init__(nombre, horas_trabajadas, tarifa_hora)
    
    def calcular_salario(self):
        return self.horas_trabajadas * self.tarifa_hora

class EmpleadoFijo(Empleado):
    
    def __init__(self, nombre, salario_fijo):
        super().__init__(nombre, 0, 0)  
        self.salario_fijo = salario_fijo
    
    def calcular_salario(self):
        return self.salario_fijo

empleado1 = EmpleadoPorHora("Juan", 40, 15)  
print(f"Salario de {empleado1.nombre}: ${empleado1.calcular_salario()}")

empleado2 = EmpleadoFijo("Ana", 2000)  
print(f"Salario de {empleado2.nombre}: ${empleado2.calcular_salario()}")
