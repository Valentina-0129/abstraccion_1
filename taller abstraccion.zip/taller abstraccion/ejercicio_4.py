from abc import ABC, abstractmethod

class Usuario(ABC):
    
    def __init__(self, nombre_usuario, contrasena):
        self.nombre_usuario = nombre_usuario
        self.contrasena = contrasena  
    
    @abstractmethod
    def verificar_usuario(self, nombre_usuario, contrasena):
        pass

    @abstractmethod
    def cambiar_contrasena(self, nueva_contrasena):
        pass

class UsuarioSistema(Usuario):
    
    def __init__(self, nombre_usuario, contrasena):
        super().__init__(nombre_usuario, contrasena)
        self.intentos_fallidos = 0  
    
    def verificar_usuario(self, nombre_usuario, contrasena):
        if nombre_usuario == self.nombre_usuario and contrasena == self.contrasena:
            self.intentos_fallidos = 0  
            return True
        else:
            self.intentos_fallidos += 1
            if self.intentos_fallidos >= 3:
                return "Cuenta bloqueada debido a múltiples intentos fallidos."
            return False
    
    def cambiar_contrasena(self, nueva_contrasena):
        self.contrasena = nueva_contrasena
        return "Contraseña cambiada con éxito."

usuario1 = UsuarioSistema("juanperez", "1234")

verificacion = usuario1.verificar_usuario("juanperez", "1234")
print(f"Verificación (correcta): {verificacion}")  

verificacion = usuario1.verificar_usuario("juanperez", "incorrecta")
print(f"Verificación (incorrecta): {verificacion}")  

cambio_contrasena = usuario1.cambiar_contrasena("nuevo1234")
print(cambio_contrasena)  

verificacion = usuario1.verificar_usuario("juanperez", "nuevo1234")
print(f"Verificación con nueva contraseña: {verificacion}")  
