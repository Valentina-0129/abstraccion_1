from abc import ABC, abstractmethod

class Menu(ABC):
    
    def __init__(self):
        self.opciones = []  
    
    @abstractmethod
    def mostrar_menu(self):
        pass
    
    @abstractmethod
    def ejecutar_opcion(self, opcion):
        pass

class MenuPrincipal(Menu):
    
    def __init__(self):
        super().__init__()
        self.opciones = [
            "1. Saludar",
            "2. Mostrar información",
            "3. Salir"
        ]
    
    def mostrar_menu(self):
        print("\n--- Menú Principal ---")
        for opcion in self.opciones:
            print(opcion)
        print("----------------------")
    
    def ejecutar_opcion(self, opcion):
        if opcion == 1:
            self.saludar()
        elif opcion == 2:
            self.mostrar_info()
        elif opcion == 3:
            print("¡Hasta luego!")
            exit()  
        else:
            print("Opción no válida. Por favor, elija una opción válida.")
    
    def saludar(self):
        print("¡Hola, bienvenido al menú!")

    def mostrar_info(self):
        print("Este es un menú de ejemplo para interactuar con el usuario.")

def ejecutar_menu():
    menu = MenuPrincipal()  
    
    while True:
        menu.mostrar_menu()  
        try:
            opcion = int(input("Elija una opción: "))  
            menu.ejecutar_opcion(opcion)  
        except ValueError:
            print("Por favor, ingrese un número válido.")

if __name__ == "__main__":
    ejecutar_menu()

    
