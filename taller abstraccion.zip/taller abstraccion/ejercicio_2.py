from abc import ABC, abstractmethod

class Estudiante(ABC):
    
    def __init__(self, nombre, notas):
        self.nombre = nombre
        self.notas = notas  
    
    @abstractmethod
    def calcular_promedio(self):
        pass

class EstudiantePromedio(Estudiante):
    
    def __init__(self, nombre, notas):
        super().__init__(nombre, notas)
    
    def calcular_promedio(self):
        if len(self.notas) == 0:
            return 0  
        
        return sum(self.notas) / len(self.notas)

estudiante1 = EstudiantePromedio("Carlos", [8, 9, 7, 6, 10])

promedio = estudiante1.calcular_promedio()

print(f"El promedio de {estudiante1.nombre} es: {promedio}")

